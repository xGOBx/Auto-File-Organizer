

1. Download the Lastest version of python if you don't already have it.(https://www.python.org/ftp/python/3.10.10/python-3.10.10-amd64.exe)
2. cmd and pip install whats in the requirements.txt
	- pip install win10toast
	- pip install pywin32

3. make a landing folder on your desktop 

4. Click/Run on the app.py, click ok.
5. Enter your Paths
	-Partition Letter: Letter of the partition you are going to use

	-Landing Path : This is the folder that you want all the files to download/land to
			This will be the folder that you change in your browser settings
			You can also put exsisting files here and it will place it accordingly
	
	-Main Storage File: This will be the folder where you actully store the sorted files

6. Restart PC and enjoy!!!